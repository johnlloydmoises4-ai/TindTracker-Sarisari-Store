using System.Threading.Channels;

namespace TindaTrack;

// Handout 1: EventArgs carries typed data from a completed store operation to its subscribers.
public sealed class SaleCompletedEventArgs(
    int transactionId,
    string referenceNumber,
    decimal total,
    int itemCount) : EventArgs
{
    public int TransactionId { get; } = transactionId;
    public string ReferenceNumber { get; } = referenceNumber;
    public decimal Total { get; } = total;
    public int ItemCount { get; } = itemCount;
}

public sealed class InventoryChangedEventArgs(
    int productId,
    string productName,
    string action,
    int stockQuantity) : EventArgs
{
    public int ProductId { get; } = productId;
    public string ProductName { get; } = productName;
    public string Action { get; } = action;
    public int StockQuantity { get; } = stockQuantity;
}

public sealed class StoreEventProcessor : BackgroundService
{
    private abstract record StoreEvent;
    private sealed record SaleCompletedStoreEvent(SaleCompletedEventArgs Details) : StoreEvent;
    private sealed record InventoryChangedStoreEvent(InventoryChangedEventArgs Details) : StoreEvent;

    private readonly ILogger<StoreEventProcessor> _logger;
    // Handout 4: A bounded, thread-safe channel passes event work from API requests to the background worker.
    private readonly Channel<StoreEvent> _events = Channel.CreateBounded<StoreEvent>(
        new BoundedChannelOptions(1024)
        {
            FullMode = BoundedChannelFullMode.Wait,
            SingleReader = true,
            SingleWriter = false
        });

    // Handout 1: Typed events use .NET's EventHandler<TEventArgs> delegate pattern.
    public event EventHandler<SaleCompletedEventArgs>? SaleCompleted;
    public event EventHandler<InventoryChangedEventArgs>? InventoryChanged;

    public StoreEventProcessor(ILogger<StoreEventProcessor> logger)
    {
        _logger = logger;
        SaleCompleted += (_, details) =>
        {
            if (!_events.Writer.TryWrite(new SaleCompletedStoreEvent(details)))
                _logger.LogError("Could not queue completion event for sale {ReferenceNumber}.", details.ReferenceNumber);
        };
        InventoryChanged += (_, details) =>
        {
            if (!_events.Writer.TryWrite(new InventoryChangedStoreEvent(details)))
                _logger.LogError("Could not queue inventory event for product {ProductID}.", details.ProductId);
        };
    }

    public void PublishSaleCompleted(SaleCompletedEventArgs details) =>
        SaleCompleted?.Invoke(this, details);

    public void PublishInventoryChanged(InventoryChangedEventArgs details) =>
        InventoryChanged?.Invoke(this, details);

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        // Handout 4: The hosted worker asynchronously consumes queued events without blocking request threads.
        await foreach (var storeEvent in _events.Reader.ReadAllAsync(stoppingToken))
        {
            switch (storeEvent)
            {
                case SaleCompletedStoreEvent sale:
                    _logger.LogInformation(
                        "Sale {ReferenceNumber} completed: transaction {TransactionID}, total {Total}, {ItemCount} item lines.",
                        sale.Details.ReferenceNumber,
                        sale.Details.TransactionId,
                        sale.Details.Total,
                        sale.Details.ItemCount);
                    break;
                case InventoryChangedStoreEvent inventory:
                    _logger.LogInformation(
                        "Inventory updated: {Action} for product {ProductID} ({ProductName}), stock now {StockQuantity}.",
                        inventory.Details.Action,
                        inventory.Details.ProductId,
                        inventory.Details.ProductName,
                        inventory.Details.StockQuantity);
                    break;
            }
        }
    }
}
