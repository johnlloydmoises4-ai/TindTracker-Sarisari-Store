using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Security.Cryptography;

namespace TindaTrack.Controllers;

[ApiController]
[Route("api/pos")]
public sealed class PosController : ControllerBase
{
    private readonly string _connectionString;
    private readonly ILogger<PosController> _logger;
    private readonly StoreEventProcessor _storeEvents;

    public PosController(
        IConfiguration configuration,
        ILogger<PosController> logger,
        StoreEventProcessor storeEvents)
    {
        _connectionString = configuration.GetConnectionString("TindaTrack")
            ?? throw new InvalidOperationException("Connection string 'TindaTrack' is not configured.");
        _logger = logger;
        _storeEvents = storeEvents;
    }

    public sealed class CartItemRequest
    {
        public int ProductID { get; set; }
        public int Quantity { get; set; }
    }

    public sealed class CheckoutRequest
    {
        public decimal FinalTotal { get; set; }
        public string? PaymentType { get; set; }
        public decimal AmountPaid { get; set; }
        public List<CartItemRequest>? Items { get; set; }
    }

    private sealed record CheckoutLine(int ProductID, int Quantity, decimal UnitPrice);

    [HttpGet("products")]
    public async Task<IActionResult> GetProducts(CancellationToken cancellationToken)
    {
        var products = new List<object>();
        await using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        const string query = """
            SELECT ProductID, ProductName, Category, Price, Unit, StockQuantity, Emoji, ImageData, Status
            FROM dbo.Products
            ORDER BY ProductName;
            """;
        await using var command = new SqlCommand(query, connection);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            products.Add(new
            {
                productID = reader.GetInt32(0),
                productName = reader.GetString(1),
                category = reader.GetString(2),
                price = reader.GetDecimal(3),
                unit = reader.GetString(4),
                stockQuantity = reader.GetInt32(5),
                emoji = reader.GetString(6),
                imageData = reader.IsDBNull(7) ? null : reader.GetString(7),
                status = reader.GetString(8)
            });
        }
        return Ok(products);
    }

    [HttpPost("checkout")]
    public async Task<IActionResult> Checkout([FromBody] CheckoutRequest request, CancellationToken cancellationToken)
    {
        if (request.Items is null || request.Items.Count is 0 or > 100)
            return BadRequest(new { success = false, message = "Add between 1 and 100 cart lines before checkout." });

        if (request.Items.Any(item => item.ProductID <= 0 || item.Quantity <= 0 || item.Quantity > 10000))
            return BadRequest(new { success = false, message = "The cart contains an invalid product or quantity." });

        var paymentType = request.PaymentType?.Trim();
        if (paymentType is not ("Cash" or "GCash"))
            return BadRequest(new { success = false, message = "Choose Cash or GCash as the payment method." });

        // Handout 2: Generic List<T> keeps cart-line order; Dictionary<TKey, TValue> merges duplicate product IDs efficiently.
        var itemQuantities = new List<CartItemRequest>(request.Items.Count);
        var quantityIndexByProduct = new Dictionary<int, int>();
        foreach (var item in request.Items)
        {
            if (quantityIndexByProduct.TryGetValue(item.ProductID, out var index))
                itemQuantities[index].Quantity += item.Quantity;
            else
            {
                quantityIndexByProduct.Add(item.ProductID, itemQuantities.Count);
                itemQuantities.Add(new CartItemRequest { ProductID = item.ProductID, Quantity = item.Quantity });
            }
        }

        if (itemQuantities.Any(item => item.Quantity > 10000))
            return BadRequest(new { success = false, message = "A product quantity exceeds the checkout limit." });

        await using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        // Handout 4: SQL row locks and the transaction prevent concurrent checkouts from overselling stock.
        await using var transaction = (SqlTransaction)await connection.BeginTransactionAsync(IsolationLevel.ReadCommitted, cancellationToken);

        try
        {
            var lines = new List<CheckoutLine>(itemQuantities.Count);
            decimal total = 0;

            foreach (var item in itemQuantities)
            {
                const string priceQuery = """
                    SELECT Price
                    FROM dbo.Products WITH (UPDLOCK, ROWLOCK)
                    WHERE ProductID = @ProductID;
                    """;
                await using var priceCommand = new SqlCommand(priceQuery, connection, transaction);
                priceCommand.Parameters.Add("@ProductID", SqlDbType.Int).Value = item.ProductID;
                var priceResult = await priceCommand.ExecuteScalarAsync(cancellationToken);
                if (priceResult is null or DBNull)
                {
                    await transaction.RollbackAsync(cancellationToken);
                    return NotFound(new { success = false, message = $"Product {item.ProductID} no longer exists." });
                }

                var unitPrice = Convert.ToDecimal(priceResult);
                lines.Add(new CheckoutLine(item.ProductID, item.Quantity, unitPrice));
                total += unitPrice * item.Quantity;
            }

            total = decimal.Round(total, 2, MidpointRounding.AwayFromZero);
            var amountPaid = paymentType == "GCash" ? total : request.AmountPaid;
            if (amountPaid < total || amountPaid <= 0)
            {
                await transaction.RollbackAsync(cancellationToken);
                return BadRequest(new { success = false, message = "The amount tendered is less than the server-calculated total." });
            }

            foreach (var line in lines)
            {
                const string updateStockQuery = """
                    UPDATE dbo.Products
                    SET StockQuantity = StockQuantity - @Quantity
                    WHERE ProductID = @ProductID AND StockQuantity >= @Quantity;
                    """;
                await using var updateCommand = new SqlCommand(updateStockQuery, connection, transaction);
                updateCommand.Parameters.Add("@Quantity", SqlDbType.Int).Value = line.Quantity;
                updateCommand.Parameters.Add("@ProductID", SqlDbType.Int).Value = line.ProductID;
                if (await updateCommand.ExecuteNonQueryAsync(cancellationToken) != 1)
                {
                    await transaction.RollbackAsync(cancellationToken);
                    return Conflict(new { success = false, message = $"There is not enough stock for product {line.ProductID}. Refresh the catalog and try again." });
                }
            }

            var changeGiven = paymentType == "Cash" ? amountPaid - total : 0m;
            var referenceNumber = $"TT-{DateTime.UtcNow:yyyyMMddHHmmss}-{RandomNumberGenerator.GetInt32(100000, 1000000)}";
            const string insertSale = """
                INSERT INTO dbo.SalesTransactions
                    (ReferenceNumber, FinalTotal, PaymentType, AmountPaid, ChangeGiven)
                OUTPUT INSERTED.TransactionID
                VALUES (@Reference, @Total, @PaymentType, @AmountPaid, @ChangeGiven);
                """;
            int transactionID;
            await using (var saleCommand = new SqlCommand(insertSale, connection, transaction))
            {
                saleCommand.Parameters.Add("@Reference", SqlDbType.VarChar, 100).Value = referenceNumber;
                saleCommand.Parameters.Add("@Total", SqlDbType.Decimal).Value = total;
                saleCommand.Parameters["@Total"].Precision = 18;
                saleCommand.Parameters["@Total"].Scale = 2;
                saleCommand.Parameters.Add("@PaymentType", SqlDbType.VarChar, 20).Value = paymentType;
                saleCommand.Parameters.Add("@AmountPaid", SqlDbType.Decimal).Value = amountPaid;
                saleCommand.Parameters["@AmountPaid"].Precision = 18;
                saleCommand.Parameters["@AmountPaid"].Scale = 2;
                saleCommand.Parameters.Add("@ChangeGiven", SqlDbType.Decimal).Value = changeGiven;
                saleCommand.Parameters["@ChangeGiven"].Precision = 18;
                saleCommand.Parameters["@ChangeGiven"].Scale = 2;
                transactionID = Convert.ToInt32(await saleCommand.ExecuteScalarAsync(cancellationToken));
            }

            const string insertLine = """
                INSERT INTO dbo.TransactionItems
                    (TransactionID, ProductID, QuantityPurchased, ItemPricePaid)
                VALUES (@TransactionID, @ProductID, @Quantity, @UnitPrice);
                """;
            foreach (var line in lines)
            {
                await using var lineCommand = new SqlCommand(insertLine, connection, transaction);
                lineCommand.Parameters.Add("@TransactionID", SqlDbType.Int).Value = transactionID;
                lineCommand.Parameters.Add("@ProductID", SqlDbType.Int).Value = line.ProductID;
                lineCommand.Parameters.Add("@Quantity", SqlDbType.Int).Value = line.Quantity;
                lineCommand.Parameters.Add("@UnitPrice", SqlDbType.Decimal).Value = line.UnitPrice;
                lineCommand.Parameters["@UnitPrice"].Precision = 18;
                lineCommand.Parameters["@UnitPrice"].Scale = 2;
                await lineCommand.ExecuteNonQueryAsync(cancellationToken);
            }

            await transaction.CommitAsync(cancellationToken);
            // Handout 1: Publish only after commit so subscribers see successful sales, never rolled-back ones.
            _storeEvents.PublishSaleCompleted(new SaleCompletedEventArgs(
                transactionID,
                referenceNumber,
                total,
                lines.Count));
            return Ok(new
            {
                success = true,
                transactionID,
                referenceNumber,
                total,
                paymentType,
                amountPaid,
                changeGiven,
                items = lines.Select(line => new
                {
                    productID = line.ProductID,
                    quantity = line.Quantity,
                    unitPrice = line.UnitPrice,
                    subtotal = line.UnitPrice * line.Quantity
                })
            });
        }
        catch (SqlException exception)
        {
            await transaction.RollbackAsync(cancellationToken);
            _logger.LogError(exception, "Checkout transaction failed.");
            return StatusCode(StatusCodes.Status500InternalServerError, new { success = false, message = "The sale could not be completed. No stock or transaction changes were saved." });
        }
        catch (OverflowException exception)
        {
            // Handout 3: Catch arithmetic overflow explicitly, log it, and return a safe validation response.
            await transaction.RollbackAsync(CancellationToken.None);
            _logger.LogWarning(exception, "Checkout total exceeded the supported monetary range.");
            return BadRequest(new { success = false, message = "The sale total exceeds the supported limit." });
        }
    }
}
