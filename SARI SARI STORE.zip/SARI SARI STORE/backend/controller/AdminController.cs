using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.Data.SqlClient;
using System.Data;
using System.Globalization;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;

namespace TindaTrack.Controllers;

[ApiController]
[Route("api/admin")]
public sealed class AdminController : ControllerBase
{
    private const int PinIterations = 120_000;
    private const string PinHashPrefix = "PBKDF2-SHA256";
    private const int MaxProductImageBytes = 2 * 1024 * 1024;
    private static readonly HashSet<string> Categories = new(StringComparer.Ordinal)
    {
        "Drinks", "Instant Food", "Snacks", "Personal Care", "E-Load", "Others"
    };
    private sealed record InventoryProduct(
        int ProductID,
        string ProductName,
        string Category,
        decimal Price,
        string Unit,
        int StockQuantity,
        string Emoji,
        string? ImageData,
        string Status);

    private readonly string _connectionString;
    private readonly ILogger<AdminController> _logger;
    private readonly StoreEventProcessor _storeEvents;

    public AdminController(
        IConfiguration configuration,
        ILogger<AdminController> logger,
        StoreEventProcessor storeEvents)
    {
        _connectionString = configuration.GetConnectionString("TindaTrack")
            ?? throw new InvalidOperationException("Connection string 'TindaTrack' is not configured.");
        _logger = logger;
        _storeEvents = storeEvents;
    }

    public sealed class PinVerifyRequest
    {
        public string? Pin { get; set; }
    }

    public sealed class CreateProductRequest
    {
        public string? ProductName { get; set; }
        public string? Category { get; set; }
        public decimal Price { get; set; }
        public string? Unit { get; set; }
        public int StockQuantity { get; set; }
        public string? Emoji { get; set; }
        public string? ImageData { get; set; }
    }

    public sealed class StockAdjustmentRequest
    {
        public int Delta { get; set; }
    }

    [AllowAnonymous]
    [EnableRateLimiting("admin-pin")]
    [HttpPost("verify-pin")]
    public async Task<IActionResult> VerifyPin([FromBody] PinVerifyRequest request, CancellationToken cancellationToken)
    {
        var pin = request.Pin;
        if (pin is null || pin.Length != 4 || pin.Any(character => character is < '0' or > '9'))
            return BadRequest(new { success = false, message = "Enter a four-digit PIN." });

        await using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        const string selectQuery = "SELECT TOP (1) HashedPIN FROM dbo.AdminPinSettings ORDER BY SettingID;";
        await using var selectCommand = new SqlCommand(selectQuery, connection);
        var hashObject = await selectCommand.ExecuteScalarAsync(cancellationToken);
        if (hashObject is null or DBNull)
        {
            _logger.LogCritical("Admin PIN is not configured in AdminPinSettings.");
            return StatusCode(StatusCodes.Status503ServiceUnavailable, new { success = false, message = "Admin PIN is not configured. Run the database setup script." });
        }

        var storedValue = Convert.ToString(hashObject, CultureInfo.InvariantCulture) ?? "";
        var isValid = VerifyStoredPin(pin, storedValue);
        if (!isValid)
            return Unauthorized(new { success = false, message = "Invalid PIN." });

        if (!storedValue.StartsWith($"{PinHashPrefix}$", StringComparison.Ordinal))
        {
            const string updateQuery = """
                UPDATE dbo.AdminPinSettings
                SET HashedPIN = @HashedPIN, LastModified = SYSDATETIME()
                WHERE SettingID = (SELECT MIN(SettingID) FROM dbo.AdminPinSettings);
                """;
            await using var updateCommand = new SqlCommand(updateQuery, connection);
            updateCommand.Parameters.Add("@HashedPIN", SqlDbType.VarChar, 255).Value = HashPin(pin);
            await updateCommand.ExecuteNonQueryAsync(cancellationToken);
        }

        var claims = new[] { new Claim(ClaimTypes.Name, "TindaTrack Admin") };
        var identity = new ClaimsIdentity(claims, CookieAuthenticationDefaults.AuthenticationScheme);
        await HttpContext.SignInAsync(
            CookieAuthenticationDefaults.AuthenticationScheme,
            new ClaimsPrincipal(identity),
            new AuthenticationProperties { IsPersistent = false, AllowRefresh = true });

        return Ok(new { success = true });
    }

    [Authorize]
    [HttpPost("logout")]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return Ok(new { success = true });
    }

    [Authorize]
    [HttpGet("overview")]
    public async Task<IActionResult> GetOverview(CancellationToken cancellationToken)
    {
        await using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);

        const string metricsQuery = """
            SELECT
                COALESCE(SUM(FinalTotal), 0),
                COUNT_BIG(*),
                COALESCE(SUM(CASE WHEN TransactionTimestamp >= CONVERT(date, SYSDATETIME()) THEN FinalTotal ELSE 0 END), 0),
                SUM(CASE WHEN TransactionTimestamp >= CONVERT(date, SYSDATETIME()) THEN CONVERT(bigint, 1) ELSE CONVERT(bigint, 0) END)
            FROM dbo.SalesTransactions;
            """;
        decimal totalRevenue;
        long transactionCount;
        decimal todayRevenue;
        long todayTransactionCount;
        await using (var metricsCommand = new SqlCommand(metricsQuery, connection))
        await using (var reader = await metricsCommand.ExecuteReaderAsync(cancellationToken))
        {
            await reader.ReadAsync(cancellationToken);
            totalRevenue = reader.GetDecimal(0);
            transactionCount = reader.GetInt64(1);
            todayRevenue = reader.GetDecimal(2);
            todayTransactionCount = reader.IsDBNull(3) ? 0 : reader.GetInt64(3);
        }

        var products = new List<InventoryProduct>();
        const string productQuery = """
            SELECT ProductID, ProductName, Category, Price, Unit, StockQuantity, Emoji, ImageData, Status
            FROM dbo.Products
            ORDER BY ProductName;
            """;
        await using (var productCommand = new SqlCommand(productQuery, connection))
        await using (var reader = await productCommand.ExecuteReaderAsync(cancellationToken))
        {
            while (await reader.ReadAsync(cancellationToken))
            {
                products.Add(new InventoryProduct(
                    reader.GetInt32(0),
                    reader.GetString(1),
                    reader.GetString(2),
                    reader.GetDecimal(3),
                    reader.GetString(4),
                    reader.GetInt32(5),
                    reader.GetString(6),
                    reader.IsDBNull(7) ? null : reader.GetString(7),
                    reader.GetString(8)));
            }
        }

        var lowStockCount = 0;
        var outOfStockCount = 0;
        foreach (var product in products)
        {
            if (product.StockQuantity == 0) outOfStockCount++;
            else if (product.StockQuantity <= 10) lowStockCount++;
        }

        return Ok(new
        {
            totalRevenue,
            transactionCount,
            lowStockCount,
            outOfStockCount,
            todayRevenue,
            todayTransactionCount,
            averageOrder = todayTransactionCount == 0 ? 0m : decimal.Round(todayRevenue / todayTransactionCount, 2),
            products
        });
    }

    [Authorize]
    [HttpGet("transactions")]
    public async Task<IActionResult> GetTransactions(CancellationToken cancellationToken)
    {
        var transactions = new List<object>();
        await using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        const string query = """
            SELECT t.TransactionID, t.ReferenceNumber, t.FinalTotal, t.PaymentType, t.AmountPaid,
                t.ChangeGiven, t.TransactionTimestamp, COALESCE(items.ItemsSummary, N'')
            FROM dbo.SalesTransactions AS t
            OUTER APPLY (
                SELECT STRING_AGG(
                    CONVERT(nvarchar(max), CONCAT(p.ProductName, N' ×', i.QuantityPurchased)),
                    N', '
                ) WITHIN GROUP (ORDER BY p.ProductName) AS ItemsSummary
                FROM dbo.TransactionItems AS i
                INNER JOIN dbo.Products AS p ON p.ProductID = i.ProductID
                WHERE i.TransactionID = t.TransactionID
            ) AS items
            ORDER BY t.TransactionTimestamp DESC, t.TransactionID DESC;
            """;
        await using var command = new SqlCommand(query, connection);
        await using var reader = await command.ExecuteReaderAsync(cancellationToken);
        while (await reader.ReadAsync(cancellationToken))
        {
            transactions.Add(new
            {
                transactionID = reader.GetInt32(0),
                referenceNumber = reader.GetString(1),
                finalTotal = reader.GetDecimal(2),
                paymentType = reader.GetString(3),
                amountPaid = reader.GetDecimal(4),
                changeGiven = reader.GetDecimal(5),
                transactionTimestamp = reader.GetDateTime(6),
                itemsSummary = reader.GetString(7)
            });
        }
        return Ok(transactions);
    }

    [Authorize]
    [HttpPost("products")]
    public async Task<IActionResult> AddProduct([FromBody] CreateProductRequest request, CancellationToken cancellationToken)
    {
        var name = request.ProductName?.Trim();
        var category = request.Category?.Trim();
        var unit = request.Unit?.Trim();
        var emoji = request.Emoji?.Trim();
        if (!TryNormalizeProductImage(request.ImageData, out var imageData))
            return BadRequest(new { success = false, message = "Choose a valid PNG, JPG, or WebP image smaller than 2 MB." });
        if (string.IsNullOrWhiteSpace(name) || name.Length > 100 ||
            category is null || !Categories.Contains(category) ||
            request.Price <= 0 || request.Price > 9_999_999_999_999_999.99m ||
            decimal.Round(request.Price, 2) != request.Price ||
            string.IsNullOrWhiteSpace(unit) || unit.Length > 20 ||
            request.StockQuantity < 0 ||
            string.IsNullOrWhiteSpace(emoji) || emoji.Length > 10)
            return BadRequest(new { success = false, message = "Enter a valid product name, category, positive price, unit, non-negative stock, and icon." });

        try
        {
            await using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync(cancellationToken);
            const string query = """
                INSERT INTO dbo.Products (ProductName, Category, Price, Unit, StockQuantity, Emoji, ImageData)
                OUTPUT INSERTED.ProductID
                VALUES (@ProductName, @Category, @Price, @Unit, @StockQuantity, @Emoji, @ImageData);
                """;
            await using var command = new SqlCommand(query, connection);
            command.Parameters.Add("@ProductName", SqlDbType.NVarChar, 100).Value = name;
            command.Parameters.Add("@Category", SqlDbType.NVarChar, 50).Value = category;
            AddDecimalParameter(command, "@Price", request.Price);
            command.Parameters.Add("@Unit", SqlDbType.NVarChar, 20).Value = unit;
            command.Parameters.Add("@StockQuantity", SqlDbType.Int).Value = request.StockQuantity;
            command.Parameters.Add("@Emoji", SqlDbType.NVarChar, 10).Value = emoji;
            command.Parameters.Add("@ImageData", SqlDbType.NVarChar, -1).Value = imageData is null ? DBNull.Value : imageData;
            var productID = Convert.ToInt32(await command.ExecuteScalarAsync(cancellationToken));
            // Handout 1: Raise the inventory event after the product insert succeeds.
            _storeEvents.PublishInventoryChanged(new InventoryChangedEventArgs(
                productID,
                name,
                "Product added",
                request.StockQuantity));
            return Created($"/api/pos/products/{productID}", new { success = true, productID });
        }
        catch (SqlException exception)
        {
            _logger.LogError(exception, "Could not add inventory product.");
            return StatusCode(StatusCodes.Status500InternalServerError, new { success = false, message = "The product could not be added." });
        }
    }

    private static bool TryNormalizeProductImage(string? imageData, out string? normalized)
    {
        normalized = null;
        if (imageData is null) return true;

        var separator = imageData.IndexOf(',');
        if (separator < 0) return false;
        var header = imageData[..separator];
        var contentType = header switch
        {
            "data:image/png;base64" => "image/png",
            "data:image/jpeg;base64" => "image/jpeg",
            "data:image/webp;base64" => "image/webp",
            _ => null
        };
        if (contentType is null) return false;

        byte[] bytes;
        try
        {
            bytes = Convert.FromBase64String(imageData[(separator + 1)..]);
        }
        catch (FormatException)
        {
            return false;
        }
        if (bytes.Length is 0 or > MaxProductImageBytes) return false;

        var validSignature = contentType switch
        {
            "image/png" => bytes.Length >= 8 &&
                bytes.AsSpan(0, 8).SequenceEqual(new byte[] { 137, 80, 78, 71, 13, 10, 26, 10 }),
            "image/jpeg" => bytes.Length >= 3 && bytes[0] == 0xFF && bytes[1] == 0xD8 && bytes[2] == 0xFF,
            "image/webp" => bytes.Length >= 12 &&
                bytes.AsSpan(0, 4).SequenceEqual("RIFF"u8) &&
                bytes.AsSpan(8, 4).SequenceEqual("WEBP"u8),
            _ => false
        };
        if (!validSignature) return false;

        normalized = $"{header},{Convert.ToBase64String(bytes)}";
        return true;
    }

    [Authorize]
    [HttpDelete("products/{id:int}")]
    public async Task<IActionResult> RemoveProduct(int id, CancellationToken cancellationToken)
    {
        if (id <= 0)
            return BadRequest(new { success = false, message = "Choose a valid product." });

        try
        {
            await using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync(cancellationToken);
            const string query = """
                DELETE FROM dbo.Products
                OUTPUT DELETED.ProductName, DELETED.StockQuantity
                WHERE ProductID = @ProductID;
                """;
            await using var command = new SqlCommand(query, connection);
            command.Parameters.Add("@ProductID", SqlDbType.Int).Value = id;
            string? productName;
            int stockQuantity;
            await using (var reader = await command.ExecuteReaderAsync(cancellationToken))
            {
                if (!await reader.ReadAsync(cancellationToken))
                    return NotFound(new { success = false, message = "Product not found." });
                productName = reader.GetString(0);
                stockQuantity = reader.GetInt32(1);
            }
            if (productName is null)
                return NotFound(new { success = false, message = "Product not found." });
            // Handout 1: Notify subscribers after a product is removed successfully.
            _storeEvents.PublishInventoryChanged(new InventoryChangedEventArgs(
                id,
                productName,
                "Product removed",
                stockQuantity));
            return Ok(new { success = true });
        }
        catch (SqlException exception) when (exception.Number == 547)
        {
            return Conflict(new
            {
                success = false,
                message = "This product is in sales history and cannot be removed."
            });
        }
        catch (SqlException exception)
        {
            _logger.LogError(exception, "Could not remove inventory product {ProductID}.", id);
            return StatusCode(StatusCodes.Status500InternalServerError, new { success = false, message = "The product could not be removed." });
        }
    }

    [Authorize]
    [HttpPatch("products/{id:int}/stock")]
    public async Task<IActionResult> AdjustStock(int id, [FromBody] StockAdjustmentRequest request, CancellationToken cancellationToken)
    {
        if (id <= 0 || (request.Delta is not (-1 or -10) && request.Delta <= 0))
            return BadRequest(new { success = false, message = "Choose -1, -10, +10, or enter a positive whole number to add." });

        await using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        const string updateQuery = """
            UPDATE dbo.Products
            SET StockQuantity = StockQuantity + @Delta
            OUTPUT INSERTED.ProductName, INSERTED.StockQuantity
            WHERE ProductID = @ProductID
                AND CONVERT(bigint, StockQuantity) + @Delta BETWEEN 0 AND 2147483647;
            """;
        await using var command = new SqlCommand(updateQuery, connection);
        command.Parameters.Add("@Delta", SqlDbType.Int).Value = request.Delta;
        command.Parameters.Add("@ProductID", SqlDbType.Int).Value = id;
        string? productName = null;
        int stockQuantity = 0;
        await using (var reader = await command.ExecuteReaderAsync(cancellationToken))
        {
            if (await reader.ReadAsync(cancellationToken))
            {
                productName = reader.GetString(0);
                stockQuantity = reader.GetInt32(1);
            }
        }
        if (productName is not null)
        {
            // Handout 1: Successful stock adjustments notify event subscribers.
            _storeEvents.PublishInventoryChanged(new InventoryChangedEventArgs(
                id,
                productName,
                "Stock adjusted",
                stockQuantity));
            return Ok(new { success = true });
        }

        const string existsQuery = "SELECT 1 FROM dbo.Products WHERE ProductID = @ProductID;";
        await using var existsCommand = new SqlCommand(existsQuery, connection);
        existsCommand.Parameters.Add("@ProductID", SqlDbType.Int).Value = id;
        var exists = await existsCommand.ExecuteScalarAsync(cancellationToken);
        if (exists is null)
            return NotFound(new { success = false, message = "Product not found." });
        return Conflict(new
        {
            success = false,
            message = request.Delta < 0
                ? "Stock cannot be reduced below zero."
                : "Stock cannot exceed the supported maximum."
        });
    }

    [Authorize]
    [HttpDelete("transactions/cancel/{id:int}")]
    public async Task<IActionResult> CancelTransaction(int id, CancellationToken cancellationToken)
    {
        if (id <= 0)
            return BadRequest(new { success = false, message = "Invalid transaction ID." });

        await using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        // Handout 3: Keep stock restoration and sale removal atomic if any step fails.
        await using var transaction = (SqlTransaction)await connection.BeginTransactionAsync(IsolationLevel.Serializable, cancellationToken);
        try
        {
            const string saleQuery = """
                SELECT ReferenceNumber
                FROM dbo.SalesTransactions WITH (UPDLOCK, HOLDLOCK)
                WHERE TransactionID = @TransactionID;
                """;
            string? referenceNumber;
            await using (var saleCommand = new SqlCommand(saleQuery, connection, transaction))
            {
                saleCommand.Parameters.Add("@TransactionID", SqlDbType.Int).Value = id;
                referenceNumber = Convert.ToString(await saleCommand.ExecuteScalarAsync(cancellationToken), CultureInfo.InvariantCulture);
            }

            if (referenceNumber is null)
            {
                await transaction.RollbackAsync(cancellationToken);
                return NotFound(new { success = false, message = "Transaction not found; it may already have been removed." });
            }

            var items = new List<(int ProductID, int Quantity)>();
            const string itemsQuery = """
                SELECT ProductID, QuantityPurchased
                FROM dbo.TransactionItems WITH (UPDLOCK, HOLDLOCK)
                WHERE TransactionID = @TransactionID;
                """;
            await using (var itemsCommand = new SqlCommand(itemsQuery, connection, transaction))
            {
                itemsCommand.Parameters.Add("@TransactionID", SqlDbType.Int).Value = id;
                await using var reader = await itemsCommand.ExecuteReaderAsync(cancellationToken);
                while (await reader.ReadAsync(cancellationToken))
                    items.Add((reader.GetInt32(0), reader.GetInt32(1)));
            }

            var inventoryChanges = new List<InventoryChangedEventArgs>(items.Count);
            foreach (var item in items)
            {
                const string restoreQuery = """
                    UPDATE dbo.Products
                    SET StockQuantity = StockQuantity + @Quantity
                    OUTPUT INSERTED.ProductName, INSERTED.StockQuantity
                    WHERE ProductID = @ProductID;
                    """;
                await using var restoreCommand = new SqlCommand(restoreQuery, connection, transaction);
                restoreCommand.Parameters.Add("@Quantity", SqlDbType.Int).Value = item.Quantity;
                restoreCommand.Parameters.Add("@ProductID", SqlDbType.Int).Value = item.ProductID;
                await using var restoreReader = await restoreCommand.ExecuteReaderAsync(cancellationToken);
                if (!await restoreReader.ReadAsync(cancellationToken))
                    throw new InvalidOperationException($"Product {item.ProductID} was not found while restoring cancelled sale stock.");
                inventoryChanges.Add(new InventoryChangedEventArgs(
                    item.ProductID,
                    restoreReader.GetString(0),
                    "Stock restored after sale cancellation",
                    restoreReader.GetInt32(1)));
            }

            const string deleteQuery = "DELETE FROM dbo.SalesTransactions WHERE TransactionID = @TransactionID;";
            await using (var deleteCommand = new SqlCommand(deleteQuery, connection, transaction))
            {
                deleteCommand.Parameters.Add("@TransactionID", SqlDbType.Int).Value = id;
                if (await deleteCommand.ExecuteNonQueryAsync(cancellationToken) != 1)
                    throw new InvalidOperationException("The transaction changed before it could be cancelled.");
            }

            await transaction.CommitAsync(cancellationToken);
            // Handout 1: Publish restored-stock events only after the cancellation transaction commits.
            foreach (var inventoryChange in inventoryChanges)
                _storeEvents.PublishInventoryChanged(inventoryChange);
            return Ok(new { success = true, referenceNumber, restoredLineCount = items.Count });
        }
        catch (SqlException exception)
        {
            await transaction.RollbackAsync(cancellationToken);
            _logger.LogError(exception, "Could not cancel transaction {TransactionID}.", id);
            return StatusCode(StatusCodes.Status500InternalServerError, new { success = false, message = "The transaction could not be cancelled. No changes were saved." });
        }
        catch (InvalidOperationException exception)
        {
            await transaction.RollbackAsync(cancellationToken);
            _logger.LogError(exception, "Inventory restore failed while cancelling transaction {TransactionID}.", id);
            return Conflict(new { success = false, message = "The transaction could not be cancelled because its inventory records have changed." });
        }
    }

    [Authorize]
    [HttpGet("analytics")]
    public async Task<IActionResult> GetAnalytics([FromQuery] string range = "week", CancellationToken cancellationToken = default)
    {
        var normalizedRange = range.Trim().ToLowerInvariant();
        DateTime startDate;
        string groupExpression;
        string labelExpression;
        switch (normalizedRange)
        {
            case "year":
                startDate = DateTime.Today.AddYears(-4);
                groupExpression = "YEAR(t.TransactionTimestamp)";
                labelExpression = "CONVERT(varchar(4), YEAR(t.TransactionTimestamp))";
                break;
            case "month":
                startDate = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1).AddMonths(-11);
                groupExpression = "DATEFROMPARTS(YEAR(t.TransactionTimestamp), MONTH(t.TransactionTimestamp), 1)";
                labelExpression = "CONCAT(YEAR(t.TransactionTimestamp), '-', RIGHT(CONCAT('0', MONTH(t.TransactionTimestamp)), 2))";
                break;
            case "week":
                normalizedRange = "week";
                startDate = DateTime.Today.AddDays(-6);
                groupExpression = "CONVERT(date, t.TransactionTimestamp)";
                labelExpression = "CONVERT(varchar(10), CONVERT(date, t.TransactionTimestamp), 23)";
                break;
            default:
                return BadRequest(new { success = false, message = "Select year, month, or week for the analytics range." });
        }

        var series = new List<object>();
        var topProducts = new List<object>();
        await using var connection = new SqlConnection(_connectionString);
        await connection.OpenAsync(cancellationToken);
        var trendQuery = $"""
            SELECT {labelExpression} AS Label, COALESCE(SUM(t.FinalTotal), 0) AS Total
            FROM dbo.SalesTransactions AS t
            WHERE t.TransactionTimestamp >= @StartDate
            GROUP BY {groupExpression}
            ORDER BY {groupExpression};
            """;
        await using (var trendCommand = new SqlCommand(trendQuery, connection))
        {
            trendCommand.Parameters.Add("@StartDate", SqlDbType.DateTime2).Value = startDate;
            await using var reader = await trendCommand.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
                series.Add(new { label = reader.GetString(0), total = reader.GetDecimal(1) });
        }

        const string productsQuery = """
            SELECT TOP (5) p.ProductName, SUM(i.QuantityPurchased) AS Quantity
            FROM dbo.TransactionItems AS i
            INNER JOIN dbo.SalesTransactions AS t ON t.TransactionID = i.TransactionID
            INNER JOIN dbo.Products AS p ON p.ProductID = i.ProductID
            WHERE t.TransactionTimestamp >= @StartDate
            GROUP BY p.ProductName
            ORDER BY SUM(i.QuantityPurchased) DESC, p.ProductName;
            """;
        await using (var productsCommand = new SqlCommand(productsQuery, connection))
        {
            productsCommand.Parameters.Add("@StartDate", SqlDbType.DateTime2).Value = startDate;
            await using var reader = await productsCommand.ExecuteReaderAsync(cancellationToken);
            while (await reader.ReadAsync(cancellationToken))
                topProducts.Add(new { productName = reader.GetString(0), quantity = reader.GetInt32(1) });
        }

        return Ok(new { range = normalizedRange, series, topProducts });
    }

    private static bool VerifyStoredPin(string pin, string storedValue)
    {
        var parts = storedValue.Split('$');
        if (parts.Length == 4 && parts[0] == PinHashPrefix &&
            int.TryParse(parts[1], NumberStyles.None, CultureInfo.InvariantCulture, out var iterations) &&
            iterations is >= 100_000 and <= 1_000_000)
        {
            try
            {
                var salt = Convert.FromBase64String(parts[2]);
                var expectedHash = Convert.FromBase64String(parts[3]);
                if (salt.Length < 16 || expectedHash.Length != 32) return false;
                var actualHash = Rfc2898DeriveBytes.Pbkdf2(pin, salt, iterations, HashAlgorithmName.SHA256, expectedHash.Length);
                return CryptographicOperations.FixedTimeEquals(actualHash, expectedHash);
            }
            catch (FormatException)
            {
                return false;
            }
        }

        var suppliedBytes = Encoding.UTF8.GetBytes(pin);
        var storedBytes = Encoding.UTF8.GetBytes(storedValue);
        return suppliedBytes.Length == storedBytes.Length && CryptographicOperations.FixedTimeEquals(suppliedBytes, storedBytes);
    }

    private static string HashPin(string pin)
    {
        var salt = RandomNumberGenerator.GetBytes(16);
        var hash = Rfc2898DeriveBytes.Pbkdf2(pin, salt, PinIterations, HashAlgorithmName.SHA256, 32);
        return $"{PinHashPrefix}${PinIterations}${Convert.ToBase64String(salt)}${Convert.ToBase64String(hash)}";
    }

    private static void AddDecimalParameter(SqlCommand command, string name, decimal value)
    {
        var parameter = command.Parameters.Add(name, SqlDbType.Decimal);
        parameter.Precision = 18;
        parameter.Scale = 2;
        parameter.Value = value;
    }
}
