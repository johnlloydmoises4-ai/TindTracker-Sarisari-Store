using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using System.Data;

namespace TindaTrack.Controllers;

[ApiController]
[Route("api/navigation")]
public sealed class NavigationController : ControllerBase
{
    private readonly string _connectionString;
    private readonly ILogger<NavigationController> _logger;

    public NavigationController(IConfiguration configuration, ILogger<NavigationController> logger)
    {
        _connectionString = configuration.GetConnectionString("TindaTrack")
            ?? throw new InvalidOperationException("Connection string 'TindaTrack' is not configured.");
        _logger = logger;
    }

    public sealed class NavigationLogRequest
    {
        public string? ActionSelected { get; set; }
    }

    [HttpPost("log-action")]
    public async Task<IActionResult> LogAction([FromBody] NavigationLogRequest request, CancellationToken cancellationToken)
    {
        var action = request.ActionSelected?.Trim();
        if (action is not ("Start_Ordering_Click" or "Admin_Panel_Click"))
            return BadRequest(new { success = false, message = "Choose a supported landing-page action." });

        try
        {
            await using var connection = new SqlConnection(_connectionString);
            await connection.OpenAsync(cancellationToken);
            const string query = "INSERT INTO dbo.LandingPageLogs (ActionSelected) VALUES (@ActionSelected);";
            await using var command = new SqlCommand(query, connection);
            command.Parameters.Add("@ActionSelected", SqlDbType.VarChar, 50).Value = action;
            await command.ExecuteNonQueryAsync(cancellationToken);
            return Ok(new { success = true });
        }
        catch (SqlException exception)
        {
            _logger.LogError(exception, "Failed to save landing-page navigation telemetry.");
            return StatusCode(StatusCodes.Status500InternalServerError, new { success = false, message = "The navigation event could not be saved." });
        }
    }
}
