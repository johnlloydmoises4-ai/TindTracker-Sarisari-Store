const API_BASE = "/api";
const isStandalone = window.location.protocol === "file:";
const maxStockQuantity = 2_147_483_647;
const maxProductImageBytes = 2 * 1024 * 1024;
const supportedProductImageTypes = new Set(["image/png", "image/jpeg", "image/webp"]);
const standaloneStorageKey = "tindatrack.standalone.v1";
let standaloneAdminAuthenticated = false;
let standaloneMemoryData = null;
let productImagePreviewUrl = null;
const currency = new Intl.NumberFormat("en-PH", { style: "currency", currency: "PHP" });
const state = {
    view: "landing",
    products: [],
    cart: [],
    category: "All",
    enteredPin: "",
    paymentType: "Cash",
    selectedTransaction: null,
    selectedProductToRemove: null,
    selectedRange: "week",
    toastTimer: null
};

const byId = (id) => document.getElementById(id);
const escapeHtml = (value) => String(value ?? "").replace(/[&<>"']/g, (character) => ({
    "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;"
}[character]));
const money = (value) => currency.format(Number(value) || 0);
const productId = (product) => Number(product.productID ?? product.ProductID);
const stockOf = (product) => Number(product.stockQuantity ?? product.StockQuantity);
const priceOf = (product) => Number(product.price ?? product.Price);
const nameOf = (product) => product.productName ?? product.ProductName ?? "";
const productImages = new Map([
    ["nescafé 3-in-1", "images (1).jpg"],
    ["c2 apple 500ml", "images (2).jpg"],
    ["lucky me pancit canton", "images (3).jpg"],
    ["lucky me la paz batchoy", "16031-1.png"],
    ["egg (per piece)", "images (4).jpg"],
    ["skyflakes crackers", "images (5).jpg"],
    ["bear brand milk 33g", "images (6).jpg"],
    ["tnt load ₱15", "images.png"],
    ["milo 22g", "4c9109_4fce10c808b34d2d8e5f0c274b6257aa~mv2.avif"],
    ["colgate 25ml", "Colgate_Great_Regular_Flavor_140g_1_1_-fotor-20240529141944.webp"],
    ["marlboro red", "ru0c76gltzsc1.jpeg"],
    ["globe load ₱20", "67a7be87f2cf1c17f2a1262fb02f0c9a.png"],
    ["coke mismo 250ml", "Untitleddesign_73.webp"],
    ["safeguard soap", "4-5.jpg"],
    ["monde sandwich bread", "Monde Wheat Bread 600g-C08UFe7CaG.jpg"],
    ["nova country cheddar", "2020777-PC-1_14.webp"],
    ["chippy corn chips", "9047-009-10-2024-110949-045.jpg"],
    ["vinegar 250ml", "17109725.jpeg"]
]);

function createStandaloneData() {
    const products = [
        ["Nescafé 3-in-1", "Drinks", 7, "sachet", 45, "☕"],
        ["C2 Apple 500ml", "Drinks", 22, "bottle", 24, "🧃"],
        ["Coke Mismo 250ml", "Drinks", 18, "bottle", 30, "🥤"],
        ["Milo 22g", "Drinks", 12, "sachet", 60, "🥛"],
        ["Lucky Me Pancit Canton", "Instant Food", 14, "pack", 40, "🍜"],
        ["Lucky Me La Paz Batchoy", "Instant Food", 14, "pack", 35, "🍲"],
        ["Monde Sandwich Bread", "Instant Food", 55, "loaf", 8, "🍞"],
        ["Egg (per piece)", "Instant Food", 8, "pcs", 90, "🥚"],
        ["Chippy Corn Chips", "Snacks", 11, "pack", 50, "🍿"],
        ["Skyflakes Crackers", "Snacks", 9, "pack", 45, "🍪"],
        ["Nova Country Cheddar", "Snacks", 11, "pack", 38, "🧀"],
        ["Bear Brand Milk 33g", "Snacks", 12, "sachet", 55, "🥛"],
        ["Safeguard Soap", "Personal Care", 22, "bar", 18, "🧼"],
        ["Colgate 25ml", "Personal Care", 18, "tube", 20, "🪥"],
        ["TNT Load ₱15", "E-Load", 15, "pin", 999, "⚡"],
        ["Globe Load ₱20", "E-Load", 20, "pin", 999, "⚡"],
        ["Marlboro Red", "Others", 5, "stick", 100, "🚬"],
        ["Vinegar 250ml", "Others", 20, "bottle", 12, "🍾"]
    ].map(([productName, category, price, unit, stockQuantity, emoji], index) => ({
        productID: index + 1, productName, category, price, unit, stockQuantity, emoji,
        status: stockQuantity === 0 ? "Out of stock" : stockQuantity <= 10 ? "Low stock" : "In stock"
    }));
    return { products, transactions: [], nextProductId: products.length + 1, nextTransactionId: 1 };
}

function getStandaloneData() {
    if (standaloneMemoryData) return standaloneMemoryData;
    const stored = localStorage.getItem(standaloneStorageKey);
    standaloneMemoryData = stored ? JSON.parse(stored) : createStandaloneData();
    if (!stored) saveStandaloneData();
    return standaloneMemoryData;
}

function saveStandaloneData() {
    localStorage.setItem(standaloneStorageKey, JSON.stringify(standaloneMemoryData));
}

function updateStandaloneProductStatus(product) {
    product.status = product.stockQuantity === 0 ? "Out of stock" : product.stockQuantity <= 10 ? "Low stock" : "In stock";
}

function standaloneOverview(data) {
    const today = new Date().toLocaleDateString("en-CA");
    const todayTransactions = data.transactions.filter((transaction) =>
        new Date(transaction.transactionTimestamp).toLocaleDateString("en-CA") === today
    );
    const todayRevenue = todayTransactions.reduce((sum, transaction) => sum + transaction.finalTotal, 0);
    return {
        totalRevenue: data.transactions.reduce((sum, transaction) => sum + transaction.finalTotal, 0),
        transactionCount: data.transactions.length,
        lowStockCount: data.products.filter((product) => product.stockQuantity > 0 && product.stockQuantity <= 10).length,
        outOfStockCount: data.products.filter((product) => product.stockQuantity === 0).length,
        todayRevenue,
        todayTransactionCount: todayTransactions.length,
        averageOrder: todayTransactions.length ? Number((todayRevenue / todayTransactions.length).toFixed(2)) : 0,
        products: data.products
    };
}

function standaloneAnalytics(data, range) {
    const normalizedRange = new URLSearchParams(range).get("range") || "week";
    const now = new Date();
    const earliest = new Date(now);
    if (normalizedRange === "year") earliest.setFullYear(now.getFullYear() - 4);
    else if (normalizedRange === "month") earliest.setMonth(now.getMonth() - 11, 1);
    else if (normalizedRange === "week") earliest.setDate(now.getDate() - 6);
    else throw new Error("Select year, month, or week for the analytics range.");
    const transactions = data.transactions.filter((transaction) =>
        new Date(transaction.transactionTimestamp) >= earliest
    );
    const totals = new Map();
    const quantities = new Map();
    for (const transaction of transactions) {
        const date = new Date(transaction.transactionTimestamp);
        const label = normalizedRange === "year"
            ? String(date.getFullYear())
            : normalizedRange === "month"
                ? `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, "0")}`
                : date.toISOString().slice(0, 10);
        totals.set(label, (totals.get(label) || 0) + transaction.finalTotal);
        for (const item of transaction.items) {
            const product = data.products.find((entry) => entry.productID === item.productID);
            if (product) quantities.set(product.productName, (quantities.get(product.productName) || 0) + item.quantity);
        }
    }
    return {
        range: normalizedRange,
        series: [...totals].sort(([left], [right]) => left.localeCompare(right)).map(([label, total]) => ({ label, total })),
        topProducts: [...quantities].sort((left, right) => right[1] - left[1]).slice(0, 5)
            .map(([productName, quantity]) => ({ productName, quantity }))
    };
}

function standaloneApiRequest(path, options) {
    const data = getStandaloneData();
    const method = options.method || "GET";
    const body = options.body ? JSON.parse(options.body) : {};
    const route = path.split("?")[0];

    if (route === "/pos/products" && method === "GET") return data.products;
    if (route === "/navigation/log-action" && method === "POST") return { success: true };
    if (route === "/admin/verify-pin" && method === "POST") {
        if (body.pin !== "1234") throw new Error("Invalid PIN.");
        standaloneAdminAuthenticated = true;
        return { success: true };
    }
    if (route.startsWith("/admin/") && route !== "/admin/verify-pin" && !standaloneAdminAuthenticated) {
        throw new Error("Admin session expired. Enter the PIN again.");
    }
    if (route === "/admin/logout" && method === "POST") {
        standaloneAdminAuthenticated = false;
        return { success: true };
    }
    if (route === "/admin/overview" && method === "GET") return standaloneOverview(data);
    if (route === "/admin/transactions" && method === "GET") {
        return [...data.transactions].sort((left, right) =>
            new Date(right.transactionTimestamp) - new Date(left.transactionTimestamp)
        );
    }
    if (route === "/admin/analytics" && method === "GET") {
        return standaloneAnalytics(data, path.split("?")[1] || "");
    }
    if (route === "/admin/products" && method === "POST") {
        const product = {
            productID: data.nextProductId++,
            productName: body.productName.trim(),
            category: body.category,
            price: Number(body.price),
            unit: body.unit.trim(),
            stockQuantity: Number(body.stockQuantity),
            emoji: body.emoji.trim(),
            imageData: body.imageData || null
        };
        if (!product.productName || !product.category || product.price <= 0 || !product.unit ||
            !Number.isInteger(product.stockQuantity) || product.stockQuantity < 0 || !product.emoji) {
            throw new Error("Enter a valid product name, category, positive price, unit, non-negative stock, and icon.");
        }
        updateStandaloneProductStatus(product);
        data.products.push(product);
        saveStandaloneData();
        return { success: true, productID: product.productID };
    }
    const removeProductMatch = route.match(/^\/admin\/products\/(\d+)$/);
    if (removeProductMatch && method === "DELETE") {
        const id = Number(removeProductMatch[1]);
        const productIndex = data.products.findIndex((product) => product.productID === id);
        if (productIndex < 0) throw new Error("Product not found.");
        if (data.transactions.some((transaction) => transaction.items.some((item) => item.productID === id))) {
            throw new Error("This product is in sales history and cannot be removed.");
        }
        data.products.splice(productIndex, 1);
        saveStandaloneData();
        return { success: true };
    }
    const stockMatch = route.match(/^\/admin\/products\/(\d+)\/stock$/);
    if (stockMatch && method === "PATCH") {
        const product = data.products.find((entry) => entry.productID === Number(stockMatch[1]));
        if (!product) throw new Error("Product not found.");
        const delta = Number(body.delta);
        if (!Number.isInteger(delta) || (delta !== -1 && delta !== -10 && delta <= 0)) {
            throw new Error("Choose -1, -10, +10, or enter a positive whole number to add.");
        }
        if (delta > maxStockQuantity) throw new Error("The stock addition exceeds the supported limit.");
        if (product.stockQuantity + delta < 0) throw new Error("Stock cannot be reduced below zero.");
        if (product.stockQuantity + delta > maxStockQuantity) throw new Error("Stock cannot exceed the supported limit.");
        product.stockQuantity += delta;
        updateStandaloneProductStatus(product);
        saveStandaloneData();
        return { success: true };
    }
    const cancelMatch = route.match(/^\/admin\/transactions\/cancel\/(\d+)$/);
    if (cancelMatch && method === "DELETE") {
        const index = data.transactions.findIndex((entry) => entry.transactionID === Number(cancelMatch[1]));
        if (index < 0) throw new Error("Transaction not found; it may already have been removed.");
        const [transaction] = data.transactions.splice(index, 1);
        for (const item of transaction.items) {
            const product = data.products.find((entry) => entry.productID === item.productID);
            if (product) {
                product.stockQuantity += item.quantity;
                updateStandaloneProductStatus(product);
            }
        }
        saveStandaloneData();
        return { success: true, referenceNumber: transaction.referenceNumber, restoredLineCount: transaction.items.length };
    }
    if (route === "/pos/checkout" && method === "POST") {
        const lines = body.items.map((item) => {
            const product = data.products.find((entry) => entry.productID === Number(item.productID));
            if (!product) throw new Error(`Product ${item.productID} no longer exists.`);
            if (!Number.isInteger(Number(item.quantity)) || Number(item.quantity) <= 0 || product.stockQuantity < Number(item.quantity)) {
                throw new Error(`There is not enough stock for ${product.productName}.`);
            }
            return { product, productID: product.productID, quantity: Number(item.quantity), unitPrice: product.price };
        });
        byId("removeProductModal").addEventListener("close", () => {
            state.selectedProductToRemove = null;
            byId("removeProductError").textContent = "";
        });
        const total = Number(lines.reduce((sum, item) => sum + item.unitPrice * item.quantity, 0).toFixed(2));
        const paymentType = body.paymentType;
        const amountPaid = paymentType === "GCash" ? total : Number(body.amountPaid);
        if (!["Cash", "GCash"].includes(paymentType) || amountPaid < total || amountPaid <= 0) {
            throw new Error("The amount tendered is less than the total.");
        }
        for (const line of lines) line.product.stockQuantity -= line.quantity;
        data.products.forEach(updateStandaloneProductStatus);
        const transaction = {
            transactionID: data.nextTransactionId++,
            referenceNumber: `TT-DEMO-${Date.now()}-${Math.floor(Math.random() * 1000)}`,
            finalTotal: total,
            paymentType,
            amountPaid,
            changeGiven: paymentType === "Cash" ? amountPaid - total : 0,
            transactionTimestamp: new Date().toISOString(),
            itemsSummary: lines.map((line) => `${line.product.productName} ×${line.quantity}`).join(", "),
            items: lines.map(({ productID, quantity, unitPrice }) => ({ productID, quantity, unitPrice }))
        };
        data.transactions.push(transaction);
        saveStandaloneData();
        return {
            success: true,
            transactionID: transaction.transactionID,
            referenceNumber: transaction.referenceNumber,
            total,
            paymentType,
            amountPaid,
            changeGiven: transaction.changeGiven,
            items: transaction.items
        };
    }
    throw new Error(`This action is not available in standalone mode: ${method} ${route}`);
}

async function apiRequest(path, options = {}) {
    if (isStandalone) return standaloneApiRequest(path, options);
    const response = await fetch(`${API_BASE}${path}`, {
        credentials: "same-origin",
        ...options,
        headers: {
            ...(options.body ? { "Content-Type": "application/json" } : {}),
            ...options.headers
        }
    });
    const body = response.status === 204 ? null : await response.json().catch(() => null);
    if (!response.ok) {
        if (response.status === 401) {
            state.enteredPin = "";
            updatePinDots();
            if (state.view === "admin") switchView("admin-auth");
        }
        throw new Error(body?.message || `Request failed (${response.status}).`);
    }
    return body;
}

function readProductImage(file) {
    if (!supportedProductImageTypes.has(file.type)) {
        throw new Error("Choose a PNG, JPG, or WebP image.");
    }
    if (file.size > maxProductImageBytes) {
        throw new Error("Choose an image smaller than 2 MB.");
    }
    return new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.addEventListener("load", () => resolve(String(reader.result)));
        reader.addEventListener("error", () => reject(new Error("The selected image could not be read.")));
        reader.readAsDataURL(file);
    });
}

function resetProductImagePreview() {
    if (productImagePreviewUrl) URL.revokeObjectURL(productImagePreviewUrl);
    productImagePreviewUrl = null;
    byId("newProductImagePreview").removeAttribute("src");
    byId("newProductImagePreview").hidden = true;
}

function updateEmojiPickerSelection() {
    const selectedEmoji = byId("newProductEmoji").value;
    document.querySelectorAll(".emoji-option").forEach((button) => {
        const selected = button.dataset.productEmoji === selectedEmoji;
        button.classList.toggle("selected", selected);
        button.setAttribute("aria-pressed", String(selected));
    });
}

function showToast(message, isError = false) {
    const toast = byId("toast");
    toast.textContent = message;
    toast.style.borderColor = isError ? "rgba(248, 113, 113, .5)" : "";
    toast.classList.add("visible");
    window.clearTimeout(state.toastTimer);
    state.toastTimer = window.setTimeout(() => toast.classList.remove("visible"), 3500);
}

function updateClock() {
    const now = new Date();
    byId("timeText").textContent = now.toLocaleTimeString("en-PH", { hour: "2-digit", minute: "2-digit" });
    byId("dateText").textContent = now.toLocaleDateString("en-PH", {
        weekday: "long", year: "numeric", month: "long", day: "numeric"
    });
}

function switchView(viewName) {
    const view = byId(`${viewName}-view`);
    if (!view) return;
    document.querySelectorAll(".view-container").forEach((container) => container.classList.remove("active"));
    view.classList.add("active");
    state.view = viewName;
    if (viewName === "pos") loadProducts();
    if (viewName === "admin-auth") {
        state.enteredPin = "";
        updatePinDots();
        byId("pinError").textContent = "";
    }
    if (viewName === "admin") loadAdminData();
}

async function logNavigation(action) {
    try {
        await apiRequest("/navigation/log-action", {
            method: "POST",
            body: JSON.stringify({ actionSelected: action })
        });
    } catch (error) {
        showToast(`Navigation could not be logged: ${error.message}`, true);
    }
}

async function loadProducts() {
    const grid = byId("productGrid");
    grid.innerHTML = '<p class="empty-state">Loading products…</p>';
    try {
        state.products = await apiRequest("/pos/products");
        renderProducts();
        renderCart();
    } catch (error) {
        const hint = isStandalone
            ? "Check that browser local storage is enabled."
            : "Check that the API and SQL Server are running.";
        grid.innerHTML = `<p class="empty-state">Unable to load products. ${escapeHtml(error.message)} ${hint}</p>`;
    }
}

function renderProducts() {
    const query = byId("productSearch").value.trim().toLocaleLowerCase();
    const products = state.products.filter((product) => {
        const categoryMatches = state.category === "All" || product.category === state.category;
        return categoryMatches && nameOf(product).toLocaleLowerCase().includes(query);
    });
    const grid = byId("productGrid");
    if (!products.length) {
        grid.innerHTML = '<p class="empty-state">No products match this search.</p>';
        return;
    }
    grid.innerHTML = products.map((product) => {
        const stock = stockOf(product);
        const statusClass = stock <= 0 ? "out" : stock <= 10 ? "low" : "";
        const quantityInCart = state.cart.find((item) => productId(item.product) === productId(product))?.quantity ?? 0;
        const imageData = product.imageData ?? product.ImageData;
        const image = imageData || productImages.get(nameOf(product).toLocaleLowerCase());
        const imageSource = imageData || (image ? `assets/${encodeURIComponent(image).replace(/%2F/g, "/")}` : "");
        return `<button class="product-card ${quantityInCart ? "selected" : ""} ${image ? "has-product-image" : ""}" type="button" data-product-id="${productId(product)}" ${stock <= 0 ? "disabled" : ""}>
            ${quantityInCart ? `<span class="product-cart-badge">${quantityInCart}</span>` : ""}
            <span class="product-card-fallback" aria-hidden="true">${escapeHtml(product.emoji)}</span>
            ${image ? `<img class="product-card-image" src="${escapeHtml(imageSource)}" alt="" aria-hidden="true" loading="lazy">` : ""}
            <span class="product-card-shade" aria-hidden="true"></span>
            <span class="product-card-content">
                <span class="product-name">${escapeHtml(nameOf(product))}</span>
                <span class="product-price">${money(priceOf(product))}</span>
            </span>
            <span class="product-stock ${statusClass}">${stock} left</span>
        </button>`;
    }).join("");
    grid.querySelectorAll(".product-card-image").forEach((image) => {
        image.addEventListener("error", () => {
            image.closest(".product-card").classList.remove("has-product-image");
            image.remove();
        }, { once: true });
    });
}

function addToCart(id) {
    const product = state.products.find((item) => productId(item) === id);
    if (!product) return;
    const existing = state.cart.find((item) => productId(item.product) === id);
    if ((existing?.quantity ?? 0) >= stockOf(product)) {
        showToast("The order quantity has reached the available stock.", true);
        return;
    }
    if (existing) existing.quantity += 1;
    else state.cart.push({ product, quantity: 1 });
    renderCart();
}

function changeCartQuantity(id, delta) {
    const item = state.cart.find((entry) => productId(entry.product) === id);
    if (!item) return;
    const nextQuantity = item.quantity + delta;
    if (nextQuantity <= 0) state.cart = state.cart.filter((entry) => productId(entry.product) !== id);
    else if (nextQuantity <= stockOf(item.product)) item.quantity = nextQuantity;
    else showToast("The order quantity cannot exceed available stock.", true);
    renderCart();
}

function cartTotal() {
    return state.cart.reduce((total, item) => total + priceOf(item.product) * item.quantity, 0);
}

function renderCart() {
    const container = byId("cartItemsContainer");
    const totalItems = state.cart.reduce((sum, item) => sum + item.quantity, 0);
    byId("cartItemBadge").textContent = totalItems;
    byId("checkoutButton").disabled = totalItems === 0;
    if (!state.cart.length) {
        container.innerHTML = '<div class="empty-cart"><span aria-hidden="true">🛍</span><p>Tap a product to add to order</p></div>';
        byId("cartItemCount").textContent = "Total (0 items)";
        byId("cartTotalPrice").textContent = money(0);
        renderProducts();
        return;
    }
    container.innerHTML = state.cart.map(({ product, quantity }) => `
        <article class="cart-item-row">
            <div class="cart-item-info">
                <span class="cart-item-emoji" aria-hidden="true">${escapeHtml(product.emoji)}</span>
                <span class="cart-item-copy">
                    <span class="cart-product-name">${escapeHtml(nameOf(product))}</span>
                    <span class="cart-line-total">${money(priceOf(product) * quantity)}</span>
                </span>
            </div>
            <div class="cart-controls">
                <button class="qty-button" type="button" data-cart-action="decrease" data-product-id="${productId(product)}" aria-label="Decrease ${escapeHtml(nameOf(product))}">−</button>
                <span class="cart-quantity">${quantity}</span>
                <button class="qty-button" type="button" data-cart-action="increase" data-product-id="${productId(product)}" aria-label="Increase ${escapeHtml(nameOf(product))}" ${quantity >= stockOf(product) ? "disabled" : ""}>+</button>
            </div>
        </article>`).join("");
    byId("cartItemCount").textContent = `Total (${totalItems} items)`;
    byId("cartTotalPrice").textContent = money(cartTotal());
    renderProducts();
}

function clearCart() {
    state.cart = [];
    renderCart();
}

function updatePinDots() {
    for (let index = 1; index <= 4; index += 1) {
        byId(`dot${index}`).classList.toggle("filled", index <= state.enteredPin.length);
    }
}

function pressPin(digit) {
    if (!/^\d$/.test(digit) || state.enteredPin.length >= 4) return;
    state.enteredPin += digit;
    byId("pinError").textContent = "";
    byId("pinError").classList.remove("pin-error-visible");
    updatePinDots();
    if (state.enteredPin.length === 4) submitPin();
}

function clearPin() {
    state.enteredPin = state.enteredPin.slice(0, -1);
    updatePinDots();
}

async function submitPin() {
    if (state.enteredPin.length !== 4) {
        byId("pinError").textContent = "Enter all four digits.";
        return;
    }
    try {
        const result = await apiRequest("/admin/verify-pin", {
            method: "POST",
            body: JSON.stringify({ pin: state.enteredPin })
        });
        if (result?.success) switchView("admin");
    } catch (error) {
        if (error.message.toLowerCase().includes("invalid pin")) {
            byId("pinError").textContent = "Incorrect PIN. Please try again.";
            document.querySelector(".pin-indicators").classList.add("error");
            window.setTimeout(() => document.querySelector(".pin-indicators").classList.remove("error"), 700);
            state.enteredPin = "";
            updatePinDots();
        } else {
            byId("pinError").textContent = error.message;
        }
    }
}

function getCheckoutTotal() {
    return Number(cartTotal().toFixed(2));
}

function prepareCheckout() {
    if (!state.cart.length) {
        showToast("Add a product before checking out.", true);
        return;
    }
    byId("checkoutModal").classList.remove("receipt-open");
    byId("checkoutCard").classList.remove("receipt-mode");
    state.paymentType = "Cash";
    byId("checkoutStep").hidden = false;
    byId("receiptStep").hidden = true;
    byId("checkoutError").textContent = "";
    byId("amountTendered").value = "";
    byId("checkoutSummary").innerHTML = state.cart.map(({ product, quantity }) => `
        <div class="checkout-summary-row"><span><span aria-hidden="true">${escapeHtml(product.emoji)}</span> ${escapeHtml(nameOf(product))} ×${quantity}</span><strong>${money(priceOf(product) * quantity)}</strong></div>
    `).join("");
    byId("checkoutTotal").textContent = money(getCheckoutTotal());
    document.querySelectorAll(".payment-option").forEach((button) => {
        const active = button.dataset.payment === state.paymentType;
        button.classList.toggle("active", active);
        button.setAttribute("aria-pressed", String(active));
    });
    renderQuickCashButtons();
    updatePaymentState();
    byId("checkoutModal").showModal();
}

function renderQuickCashButtons() {
    const total = getCheckoutTotal();
    const values = [...new Set([
        total,
        Math.ceil(total / 10) * 10 + 10,
        Math.ceil(total / 100) * 100
    ])];
    byId("quickCashButtons").innerHTML = values.map((amount) =>
        `<button class="quick-cash-button" type="button" data-cash-amount="${amount}">${money(amount)}</button>`
    ).join("");
}

function updatePaymentState() {
    const isCash = state.paymentType === "Cash";
    byId("cashPaymentFields").hidden = !isCash;
    byId("gcashPaymentFields").hidden = isCash;
    const amount = isCash ? Number(byId("amountTendered").value) : getCheckoutTotal();
    const difference = amount - getCheckoutTotal();
    const message = byId("changeMessage");
    if (!isCash) {
        message.textContent = "";
        message.className = "change-message";
        byId("confirmPaymentButton").disabled = false;
        return;
    }
    if (!Number.isFinite(amount) || amount <= 0) {
        message.textContent = "";
        message.className = "change-message";
        byId("confirmPaymentButton").disabled = true;
    } else if (difference >= -0.001) {
        message.textContent = `Change: ${money(Math.max(0, difference))}`;
        message.className = "change-message success";
        byId("confirmPaymentButton").disabled = false;
    } else {
        message.textContent = `Incomplete Amount: Need ${money(Math.abs(difference))} more`;
        message.className = "change-message incomplete";
        byId("confirmPaymentButton").disabled = true;
    }
}

async function confirmPayment() {
    const button = byId("confirmPaymentButton");
    if (button.disabled) return;
    button.disabled = true;
    button.textContent = "Processing…";
    byId("checkoutError").textContent = "";
    const total = getCheckoutTotal();
    const amountPaid = state.paymentType === "Cash" ? Number(byId("amountTendered").value) : total;
    try {
        const receipt = await apiRequest("/pos/checkout", {
            method: "POST",
            body: JSON.stringify({
                finalTotal: total,
                paymentType: state.paymentType,
                amountPaid,
                items: state.cart.map(({ product, quantity }) => ({
                    productID: productId(product),
                    quantity
                }))
            })
        });
        renderReceipt(receipt);
        await loadProducts();
    } catch (error) {
        byId("checkoutError").textContent = error.message;
        button.disabled = false;
    } finally {
        button.textContent = "✓ Confirm Payment";
        updatePaymentState();
    }
}

function renderReceipt(receipt) {
    byId("checkoutModal").classList.add("receipt-open");
    byId("checkoutCard").classList.add("receipt-mode");
    byId("checkoutStep").hidden = true;
    byId("receiptStep").hidden = false;
    const receiptTime = new Date().toLocaleTimeString("en-PH", { hour: "2-digit", minute: "2-digit" });
    byId("receiptReference").textContent = `Ref: ${receipt.referenceNumber} • ${receiptTime}`;
    const items = state.cart.map(({ product, quantity }) =>
        `<div class="receipt-line receipt-product"><span>${escapeHtml(nameOf(product))} ×${quantity}</span><strong>${money(priceOf(product) * quantity)}</strong></div>`
    ).join("");
    byId("receiptLines").innerHTML = `${items}
        <div class="receipt-line receipt-detail"><span>Subtotal</span><span>${money(receipt.total)}</span></div>
        <div class="receipt-line receipt-detail"><span>Payment</span><span>${escapeHtml(receipt.paymentType)} ${money(receipt.amountPaid)}</span></div>
        <div class="receipt-line receipt-change"><span>Change</span><strong>${money(receipt.changeGiven)}</strong></div>`;
    byId("receiptTotal").textContent = money(receipt.total);
}

async function loadAdminData() {
    try {
        const [overview, transactions] = await Promise.all([
            apiRequest("/admin/overview"),
            apiRequest("/admin/transactions")
        ]);
        renderOverview(overview);
        renderTransactions(transactions, byId("recentTransactions"), 6);
        renderTransactions(transactions, byId("allTransactions"));
        renderInventory(overview.products ?? []);
        renderSalesMetrics(overview);
        if (!byId("analyticsPanel").hidden) await loadAnalytics();
    } catch (error) {
        if (state.view === "admin") showToast(`Could not load admin data: ${error.message}`, true);
    }
}

function renderOverview(overview) {
    byId("metricRevenue").textContent = money(overview.totalRevenue);
    byId("metricTransactions").textContent = overview.transactionCount ?? 0;
    byId("metricLowStock").textContent = overview.lowStockCount ?? 0;
    byId("metricOutStock").textContent = overview.outOfStockCount ?? 0;
    const lowStock = (overview.products ?? []).filter((product) => stockOf(product) > 0 && stockOf(product) <= 10);
    byId("lowStockList").innerHTML = lowStock.length
        ? lowStock.map((product) =>
            `<span class="low-stock-tag">${escapeHtml(product.emoji)} ${escapeHtml(nameOf(product))} — ${stockOf(product)} left</span>`
        ).join("")
        : '<span class="low-stock-empty">No low-stock products. Your shelves are looking good.</span>';
}

function renderSalesMetrics(overview) {
    byId("todayRevenue").textContent = money(overview.todayRevenue);
    byId("salesTransactionCount").textContent = overview.transactionCount ?? 0;
    byId("averageOrder").textContent = money(overview.averageOrder);
}

function renderTransactions(transactions, tbody, limit = Number.POSITIVE_INFINITY) {
    const rows = transactions.slice(0, limit);
    tbody.innerHTML = rows.length ? rows.map((transaction) => {
        const id = Number(transaction.transactionID);
        const ref = escapeHtml(transaction.referenceNumber);
        const payment = escapeHtml(transaction.paymentType);
        const date = new Date(transaction.transactionTimestamp).toLocaleString("en-PH", {
            year: "numeric", month: "short", day: "numeric", hour: "2-digit", minute: "2-digit"
        });
        return `<tr>
            <td class="reference-code">${ref}</td>
            <td class="transaction-items">${escapeHtml(transaction.itemsSummary || "No item details")}</td>
            <td>${escapeHtml(date)}</td>
            <td><span class="payment-badge ${payment === "Cash" ? "cash" : ""}">${payment}</span></td>
            <td>${money(transaction.finalTotal)}</td>
            <td><button class="remove-transaction" type="button" data-cancel-id="${id}" data-cancel-ref="${ref}" data-cancel-total="${Number(transaction.finalTotal)}">Remove</button></td>
        </tr>`;
    }).join("") : '<tr><td colspan="6">No transactions have been recorded yet.</td></tr>';
}

function renderInventory(products) {
    const tbody = byId("inventoryRows");
    tbody.innerHTML = products.length ? products.map((product) => {
        const stock = stockOf(product);
        const status = stock === 0 ? "Out of stock" : stock <= 10 ? "Low stock" : "In stock";
        const className = stock === 0 ? "out-stock" : stock <= 10 ? "low-stock" : "in-stock";
        return `<tr>
            <td>${escapeHtml(product.emoji)} ${escapeHtml(nameOf(product))}</td>
            <td>${escapeHtml(product.category)}</td>
            <td>${money(priceOf(product))}</td>
            <td>${stock} ${escapeHtml(product.unit)}</td>
            <td><span class="stock-status ${className}">${status}</span></td>
            <td><div class="stock-adjust">
                <button type="button" data-stock-id="${productId(product)}" data-stock-delta="-1" aria-label="Remove 1 ${escapeHtml(nameOf(product))}">−1</button>
                <button type="button" data-stock-id="${productId(product)}" data-stock-delta="-10" aria-label="Remove 10 ${escapeHtml(nameOf(product))}">−10</button>
                <button type="button" data-stock-id="${productId(product)}" data-stock-delta="10" aria-label="Add 10 ${escapeHtml(nameOf(product))}">+10</button>
                <span class="custom-stock-adjust">
                    <input type="number" min="1" max="${maxStockQuantity}" step="1" inputmode="numeric" data-stock-amount aria-label="Quantity to add to ${escapeHtml(nameOf(product))}" placeholder="Qty">
                    <button type="button" data-stock-add data-stock-id="${productId(product)}">Add</button>
                </span>
                <button class="remove-product-button" type="button" data-remove-product-id="${productId(product)}" data-remove-product-name="${escapeHtml(nameOf(product))}" aria-label="Remove ${escapeHtml(nameOf(product))}">Remove</button>
            </div></td>
        </tr>`;
    }).join("") : '<tr><td colspan="6">No inventory products are available.</td></tr>';
}

async function adjustStock(id, delta) {
    try {
        await apiRequest(`/admin/products/${id}/stock`, {
            method: "PATCH",
            body: JSON.stringify({ delta })
        });
        const overview = await apiRequest("/admin/overview");
        renderOverview(overview);
        renderInventory(overview.products ?? []);
        renderSalesMetrics(overview);
        showToast("Inventory stock updated.");
    } catch (error) {
        showToast(`Stock update failed: ${error.message}`, true);
    }
}

async function removeProduct(id) {
    try {
        await apiRequest(`/admin/products/${id}`, { method: "DELETE" });
        state.products = state.products.filter((product) => productId(product) !== id);
        state.cart = state.cart.filter((item) => productId(item.product) !== id);
        byId("removeProductModal").close();
        await loadAdminData();
        renderCart();
        showToast("Product removed from inventory.");
    } catch (error) {
        byId("removeProductError").textContent = error.message;
    }
}

function setAdminTab(tab) {
    document.querySelectorAll(".admin-tab[data-admin-tab]").forEach((button) => {
        button.classList.toggle("active", button.dataset.adminTab === tab);
    });
    document.querySelectorAll(".admin-panel").forEach((panel) => panel.classList.remove("active"));
    byId(`admin-${tab}`).classList.add("active");
    if (tab === "sales") loadAdminData();
}

async function createProduct(event) {
    event.preventDefault();
    const form = event.currentTarget;
    const formData = new FormData(form);
    const payload = {
        productName: String(formData.get("productName")).trim(),
        price: Number(formData.get("price")),
        unit: String(formData.get("unit")).trim(),
        stockQuantity: Number(formData.get("stockQuantity")),
        emoji: String(formData.get("emoji")).trim(),
        category: String(formData.get("category")),
        imageData: null
    };
    try {
        const imageFile = formData.get("image");
        if (imageFile instanceof File && imageFile.size > 0) {
            payload.imageData = await readProductImage(imageFile);
        }
        await apiRequest("/admin/products", { method: "POST", body: JSON.stringify(payload) });
        form.reset();
        byId("newProductEmoji").value = "🛍";
        resetProductImagePreview();
        byId("productFormError").textContent = "";
        byId("productModal").close();
        await loadAdminData();
        showToast("Product added to inventory.");
    } catch (error) {
        byId("productFormError").textContent = error.message;
    }
}

function openCancelDialog(button) {
    state.selectedTransaction = Number(button.dataset.cancelId);
    byId("cancelMessage").textContent =
        `Cancel Ref #${button.dataset.cancelRef}? This will remove ${money(button.dataset.cancelTotal)} from sales and return all ordered items to inventory.`;
    byId("cancelError").textContent = "";
    byId("cancelModal").showModal();
}

async function cancelTransaction() {
    if (!state.selectedTransaction) return;
    const button = byId("confirmCancelButton");
    button.disabled = true;
    try {
        await apiRequest(`/admin/transactions/cancel/${state.selectedTransaction}`, { method: "DELETE" });
        byId("cancelModal").close();
        await loadAdminData();
        showToast("Transaction removed and inventory restored.");
    } catch (error) {
        byId("cancelError").textContent = error.message;
    } finally {
        button.disabled = false;
    }
}

async function loadAnalytics() {
    const panel = byId("trendChart");
    panel.innerHTML = '<p class="empty-state">Loading sales analytics…</p>';
    try {
        const data = await apiRequest(`/admin/analytics?range=${encodeURIComponent(state.selectedRange)}`);
        renderTrendChart(data.series ?? []);
        renderTopProducts(data.topProducts ?? []);
    } catch (error) {
        panel.innerHTML = `<p class="empty-state">Unable to load analytics: ${escapeHtml(error.message)}</p>`;
    }
}

function renderTrendChart(series) {
    const width = 760;
    const height = 230;
    const padding = { top: 30, right: 20, bottom: 38, left: 52 };
    const plotWidth = width - padding.left - padding.right;
    const plotHeight = height - padding.top - padding.bottom;
    const maxValue = Math.max(1, ...series.map((point) => Number(point.total) || 0));
    const points = series.map((point, index) => ({
        x: padding.left + (series.length <= 1 ? plotWidth / 2 : index * plotWidth / (series.length - 1)),
        y: padding.top + plotHeight - (Number(point.total) || 0) / maxValue * plotHeight,
        label: String(point.label ?? ""),
        total: Number(point.total) || 0
    }));
    const line = points.map((point) => `${point.x},${point.y}`).join(" ");
    const area = points.length ? `${padding.left},${padding.top + plotHeight} ${line} ${padding.left + plotWidth},${padding.top + plotHeight}` : "";
    const grid = [0, 1, 2, 3].map((index) => {
        const y = padding.top + index * plotHeight / 3;
        return `<line class="chart-gridline" x1="${padding.left}" y1="${y}" x2="${padding.left + plotWidth}" y2="${y}"></line>
            <text class="chart-label" x="${padding.left - 8}" y="${y + 4}" text-anchor="end">${escapeHtml(money(maxValue * (3 - index) / 3).replace("PHP", "₱"))}</text>`;
    }).join("");
    const labels = points.map((point, index) => {
        if (index !== 0 && index !== points.length - 1 && index % Math.ceil(points.length / 5) !== 0) return "";
        const anchor = points.length === 1 || (index !== 0 && index !== points.length - 1)
            ? "middle"
            : index === 0 ? "start" : "end";
        return `<text class="chart-label" x="${point.x}" y="${height - 10}" text-anchor="${anchor}">${escapeHtml(point.label)}</text>`;
    }).join("");
    const markerPoints = points.map((point) => `
        <circle class="chart-point" cx="${point.x}" cy="${point.y}" r="4">
            <title>${escapeHtml(point.label)}: ${escapeHtml(money(point.total))}</title>
        </circle>
        <text class="chart-value" x="${point.x}" y="${point.y - 9}" text-anchor="middle">${escapeHtml(money(point.total))}</text>`
    ).join("");
    byId("trendChart").innerHTML = `<svg viewBox="0 0 ${width} ${height}" role="img" aria-label="Sales over time">
        <defs><linearGradient id="chartFill" x1="0" x2="0" y1="0" y2="1"><stop offset="0%" stop-color="#f59e0b" stop-opacity=".28"></stop><stop offset="100%" stop-color="#f59e0b" stop-opacity="0"></stop></linearGradient></defs>
        ${grid}
        ${points.length ? `<polygon class="chart-area" points="${area}"></polygon><polyline class="chart-line" points="${line}"></polyline>${markerPoints}` : ""}
        ${labels}
        ${!series.length ? '<text class="chart-label" x="380" y="110" text-anchor="middle">No sales data for this period</text>' : ""}
    </svg>`;
}

function renderTopProducts(products) {
    const maxQuantity = Math.max(1, ...products.map((product) => Number(product.quantity) || 0));
    byId("topProducts").innerHTML = products.length ? products.map((product) => {
        const quantity = Number(product.quantity) || 0;
        const percentage = Math.max(0, Math.min(100, quantity / maxQuantity * 100));
        return `<div class="top-product-row">
            <span class="top-product-name">${escapeHtml(product.productName)}</span>
            <span class="top-product-track"><span class="top-product-fill" style="display:block;width:${percentage}%"></span></span>
            <span class="top-product-count">${quantity} sold</span>
        </div>`;
    }).join("") : '<p class="empty-state">No product sales to rank yet.</p>';
}

document.addEventListener("click", async (event) => {
    const target = event.target.closest("button");
    if (!target) return;

    if (target.dataset.logAction) {
        void logNavigation(target.dataset.logAction);
        switchView(target.dataset.view);
        return;
    }
    if (target.dataset.view) {
        switchView(target.dataset.view);
        return;
    }
    if (target.dataset.category) {
        state.category = target.dataset.category;
        document.querySelectorAll(".pill").forEach((button) => {
            const active = button.dataset.category === state.category;
            button.classList.toggle("active", active);
            button.setAttribute("aria-pressed", String(active));
        });
        renderProducts();
        return;
    }
    if (target.dataset.productEmoji) {
        byId("newProductEmoji").value = target.dataset.productEmoji;
        updateEmojiPickerSelection();
        return;
    }
    if (target.dataset.productId && target.classList.contains("product-card")) {
        addToCart(Number(target.dataset.productId));
        return;
    }
    if (target.dataset.cartAction) {
        const id = Number(target.dataset.productId);
        if (target.dataset.cartAction === "remove") state.cart = state.cart.filter((item) => productId(item.product) !== id);
        else changeCartQuantity(id, target.dataset.cartAction === "increase" ? 1 : -1);
        renderCart();
        return;
    }
    if (target.id === "clearCartButton") {
        clearCart();
        return;
    }
    if (target.id === "checkoutButton") {
        prepareCheckout();
        return;
    }
    if (target.dataset.pin) {
        pressPin(target.dataset.pin);
        return;
    }
    if (target.dataset.pinAction === "delete") {
        clearPin();
        return;
    }
    if (target.dataset.pinAction === "submit") {
        await submitPin();
        return;
    }
    if (target.dataset.payment) {
        state.paymentType = target.dataset.payment;
        document.querySelectorAll(".payment-option").forEach((button) => {
            const active = button.dataset.payment === state.paymentType;
            button.classList.toggle("active", active);
            button.setAttribute("aria-pressed", String(active));
        });
        updatePaymentState();
        return;
    }
    if (target.dataset.cashAmount) {
        byId("amountTendered").value = target.dataset.cashAmount;
        updatePaymentState();
        return;
    }
    if (target.id === "confirmPaymentButton") {
        await confirmPayment();
        return;
    }
    if (target.id === "newOrderButton") {
        clearCart();
        byId("checkoutModal").close();
        switchView("pos");
        return;
    }
    if (target.hasAttribute("data-close-modal")) {
        target.closest("dialog")?.close();
        return;
    }
    if (target.dataset.adminTab) {
        setAdminTab(target.dataset.adminTab);
        return;
    }
    if (target.hasAttribute("data-admin-exit")) {
        try {
            await apiRequest("/admin/logout", { method: "POST" });
        } catch (error) {
            showToast(`Could not end the admin session: ${error.message}`, true);
        }
        switchView("landing");
        return;
    }
    if (target.hasAttribute("data-refresh-admin")) {
        await loadAdminData();
        showToast("Admin data refreshed.");
        return;
    }
    if (target.id === "addProductButton") {
        byId("productFormError").textContent = "";
        byId("productModal").showModal();
        return;
    }
    if (target.dataset.removeProductId) {
        state.selectedProductToRemove = Number(target.dataset.removeProductId);
        byId("removeProductMessage").textContent =
            `Remove ${target.dataset.removeProductName} from inventory? Products recorded in sales history cannot be removed.`;
        byId("removeProductError").textContent = "";
        byId("removeProductModal").showModal();
        return;
    }
    if (target.id === "confirmRemoveProductButton") {
        if (state.selectedProductToRemove !== null) await removeProduct(state.selectedProductToRemove);
        return;
    }
    if (target.dataset.stockDelta && target.dataset.stockId) {
        await adjustStock(Number(target.dataset.stockId), Number(target.dataset.stockDelta));
        return;
    }
    if (target.hasAttribute("data-stock-add")) {
        const input = target.closest(".custom-stock-adjust").querySelector("[data-stock-amount]");
        const amount = Number(input.value);
        if (!Number.isInteger(amount) || amount < 1 || amount > maxStockQuantity) {
            showToast("Enter a positive whole-number quantity within the supported stock limit.", true);
            input.focus();
            return;
        }
        await adjustStock(Number(target.dataset.stockId), amount);
        return;
    }
    if (target.dataset.cancelId) {
        openCancelDialog(target);
        return;
    }
    if (target.id === "confirmCancelButton") {
        await cancelTransaction();
        return;
    }
    if (target.id === "analysisToggle") {
        const panel = byId("analyticsPanel");
        panel.hidden = !panel.hidden;
        if (!panel.hidden) await loadAnalytics();
        return;
    }
    if (target.dataset.range) {
        state.selectedRange = target.dataset.range;
        document.querySelectorAll(".range-pill").forEach((button) => button.classList.toggle("active", button.dataset.range === state.selectedRange));
        await loadAnalytics();
    }
});

byId("productSearch").addEventListener("input", renderProducts);
byId("amountTendered").addEventListener("input", updatePaymentState);
byId("productForm").addEventListener("submit", createProduct);
byId("newProductEmoji").addEventListener("input", updateEmojiPickerSelection);
byId("productModal").addEventListener("close", updateEmojiPickerSelection);
byId("newProductImage").addEventListener("change", () => {
    const file = byId("newProductImage").files[0];
    if (!file) {
        resetProductImagePreview();
        return;
    }
    try {
        if (!supportedProductImageTypes.has(file.type)) throw new Error("Choose a PNG, JPG, or WebP image.");
        if (file.size > maxProductImageBytes) throw new Error("Choose an image smaller than 2 MB.");
        resetProductImagePreview();
        productImagePreviewUrl = URL.createObjectURL(file);
        byId("newProductImagePreview").src = productImagePreviewUrl;
        byId("newProductImagePreview").hidden = false;
        byId("productFormError").textContent = "";
    } catch (error) {
        byId("newProductImage").value = "";
        resetProductImagePreview();
        byId("productFormError").textContent = error.message;
    }
});
byId("productModal").addEventListener("close", () => {
    byId("newProductImage").value = "";
    resetProductImagePreview();
});
document.addEventListener("keydown", (event) => {
    if (state.view !== "admin-auth") return;
    if (/^\d$/.test(event.key)) pressPin(event.key);
    else if (event.key === "Backspace") clearPin();
    else if (event.key === "Enter") submitPin();
});

updateClock();
window.setInterval(updateClock, 1000);
if (isStandalone) byId("standaloneNote").hidden = false;
