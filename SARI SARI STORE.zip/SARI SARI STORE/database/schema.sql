IF DB_ID(N'TindaTrackDB') IS NULL
BEGIN
    CREATE DATABASE TindaTrackDB;
END;
GO

USE TindaTrackDB;
GO

IF OBJECT_ID(N'dbo.LandingPageLogs', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.LandingPageLogs (
        LogID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_LandingPageLogs PRIMARY KEY,
        ActionSelected VARCHAR(50) NOT NULL,
        TimestampLogged DATETIME2(0) NOT NULL CONSTRAINT DF_LandingPageLogs_Timestamp DEFAULT SYSDATETIME(),
        CONSTRAINT CK_LandingPageLogs_Action CHECK (ActionSelected IN ('Start_Ordering_Click', 'Admin_Panel_Click'))
    );
END;
GO

IF OBJECT_ID(N'dbo.Products', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Products (
        ProductID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_Products PRIMARY KEY,
        ProductName NVARCHAR(100) NOT NULL,
        Category NVARCHAR(50) NOT NULL,
        Price DECIMAL(18,2) NOT NULL,
        Unit NVARCHAR(20) NOT NULL,
        StockQuantity INT NOT NULL,
        Emoji NVARCHAR(10) NOT NULL,
        ImageData NVARCHAR(MAX) NULL,
        Status AS (
            CASE
                WHEN StockQuantity = 0 THEN 'Out of stock'
                WHEN StockQuantity <= 10 THEN 'Low stock'
                ELSE 'In stock'
            END
        ),
        CONSTRAINT CK_Products_Price CHECK (Price > 0),
        CONSTRAINT CK_Products_StockQuantity CHECK (StockQuantity >= 0)
    );
END;
GO

IF COL_LENGTH(N'dbo.Products', N'ImageData') IS NULL
BEGIN
    ALTER TABLE dbo.Products ADD ImageData NVARCHAR(MAX) NULL;
END;
GO

IF OBJECT_ID(N'dbo.SalesTransactions', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SalesTransactions (
        TransactionID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_SalesTransactions PRIMARY KEY,
        ReferenceNumber VARCHAR(100) NOT NULL CONSTRAINT UQ_SalesTransactions_ReferenceNumber UNIQUE,
        FinalTotal DECIMAL(18,2) NOT NULL,
        PaymentType VARCHAR(20) NOT NULL,
        AmountPaid DECIMAL(18,2) NOT NULL,
        ChangeGiven DECIMAL(18,2) NOT NULL,
        TransactionTimestamp DATETIME2(0) NOT NULL CONSTRAINT DF_SalesTransactions_Timestamp DEFAULT SYSDATETIME(),
        CONSTRAINT CK_SalesTransactions_Total CHECK (FinalTotal >= 0),
        CONSTRAINT CK_SalesTransactions_Payment CHECK (PaymentType IN ('Cash', 'GCash')),
        CONSTRAINT CK_SalesTransactions_Paid CHECK (AmountPaid >= FinalTotal),
        CONSTRAINT CK_SalesTransactions_Change CHECK (ChangeGiven >= 0)
    );
END;
GO

IF OBJECT_ID(N'dbo.TransactionItems', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.TransactionItems (
        LineItemID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_TransactionItems PRIMARY KEY,
        TransactionID INT NOT NULL,
        ProductID INT NOT NULL,
        QuantityPurchased INT NOT NULL,
        ItemPricePaid DECIMAL(18,2) NOT NULL,
        CONSTRAINT FK_TransactionItems_Transactions FOREIGN KEY (TransactionID)
            REFERENCES dbo.SalesTransactions(TransactionID) ON DELETE CASCADE,
        CONSTRAINT FK_TransactionItems_Products FOREIGN KEY (ProductID)
            REFERENCES dbo.Products(ProductID),
        CONSTRAINT CK_TransactionItems_Quantity CHECK (QuantityPurchased > 0),
        CONSTRAINT CK_TransactionItems_Price CHECK (ItemPricePaid > 0)
    );
END;
GO

IF OBJECT_ID(N'dbo.AdminPinSettings', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.AdminPinSettings (
        SettingID INT IDENTITY(1,1) NOT NULL CONSTRAINT PK_AdminPinSettings PRIMARY KEY,
        HashedPIN VARCHAR(255) NOT NULL,
        LastModified DATETIME2(0) NOT NULL CONSTRAINT DF_AdminPinSettings_LastModified DEFAULT SYSDATETIME()
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.AdminPinSettings WHERE SettingID = 1)
BEGIN
    INSERT INTO dbo.AdminPinSettings (HashedPIN)
    VALUES ('PBKDF2-SHA256$120000$VGluZGFUcmFja1NhbHQyMDI2$Ee/pT0BG0mvU3NzNVSlwu90rc9QX3lW4bSTHQDjPE2A=');
END;
GO

IF NOT EXISTS (SELECT 1 FROM dbo.Products)
BEGIN
    INSERT INTO dbo.Products (ProductName, Category, Price, Unit, StockQuantity, Emoji) VALUES
        (N'Nescafé 3-in-1', N'Drinks', 7.00, N'sachet', 45, N'☕'),
        (N'C2 Apple 500ml', N'Drinks', 22.00, N'bottle', 24, N'🧃'),
        (N'Coke Mismo 250ml', N'Drinks', 18.00, N'bottle', 30, N'🥤'),
        (N'Milo 22g', N'Drinks', 12.00, N'sachet', 60, N'🥛'),
        (N'Lucky Me Pancit Canton', N'Instant Food', 14.00, N'pack', 40, N'🍜'),
        (N'Lucky Me La Paz Batchoy', N'Instant Food', 14.00, N'pack', 35, N'🍲'),
        (N'Monde Sandwich Bread', N'Instant Food', 55.00, N'loaf', 8, N'🍞'),
        (N'Egg (per piece)', N'Instant Food', 8.00, N'pcs', 90, N'🥚'),
        (N'Chippy Corn Chips', N'Snacks', 11.00, N'pack', 50, N'🍿'),
        (N'Skyflakes Crackers', N'Snacks', 9.00, N'pack', 45, N'🍪'),
        (N'Nova Country Cheddar', N'Snacks', 11.00, N'pack', 38, N'🧀'),
        (N'Bear Brand Milk 33g', N'Snacks', 12.00, N'sachet', 55, N'🥛'),
        (N'Safeguard Soap', N'Personal Care', 22.00, N'bar', 18, N'🧼'),
        (N'Colgate 25ml', N'Personal Care', 18.00, N'tube', 20, N'🪥'),
        (N'TNT Load ₱15', N'E-Load', 15.00, N'pin', 999, N'⚡'),
        (N'Globe Load ₱20', N'E-Load', 20.00, N'pin', 999, N'⚡'),
        (N'Marlboro Red', N'Others', 5.00, N'stick', 100, N'🚬'),
        (N'Vinegar 250ml', N'Others', 20.00, N'bottle', 12, N'🍾');
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_TransactionItems_TransactionID' AND object_id = OBJECT_ID(N'dbo.TransactionItems'))
BEGIN
    CREATE INDEX IX_TransactionItems_TransactionID ON dbo.TransactionItems (TransactionID);
END;
GO

IF NOT EXISTS (SELECT 1 FROM sys.indexes WHERE name = N'IX_SalesTransactions_Timestamp' AND object_id = OBJECT_ID(N'dbo.SalesTransactions'))
BEGIN
    CREATE INDEX IX_SalesTransactions_Timestamp ON dbo.SalesTransactions (TransactionTimestamp);
END;
GO
